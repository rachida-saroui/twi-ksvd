# UMD dataset

UMD is a synthetic data set with 3 classes: one class is characterized by a small up bell arising at the initial or final period (Up); one does not have any bell (Middle); one has a small down bell arising at the initial or final period (Down).

- Class 1: Up
- Class 2: Middle
- Class 3: Down

Train size: 36

Test size: 144

Missing value: No

Number of classses: 3

Time series length: 150

Data source: Université Joseph Fourier (Grenoble I), Laboratoire d’informatique de Grenoble(LIG), Equipe AMA